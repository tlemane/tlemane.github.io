```bash
setconda
conda env create -f environment.yml -p climap_tutorial
conda activate ./climap_tutorial
cd src
poetry install
```

```bash
python -m climap train --help
```
