import sys
from loguru import logger

log_fmt = (
    "<blue>{time:YYYY-MM-DD HH:mm:ss.SSS}</blue> | "
    "<level>{level: <4}</level> | "
    "<white><bold>{message}</bold></white>"
)
logger.remove()

logger.add(sys.stderr, format=log_fmt, colorize=True, backtrace=False, diagnose=False)
logger.level("INFO", color="<green><bold>")
