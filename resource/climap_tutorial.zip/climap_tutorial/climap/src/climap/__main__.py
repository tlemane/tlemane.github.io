import argparse
import os

import warnings
warnings.filterwarnings("ignore")
os.environ['PYTHONWARNINGS']='ignore'

from climap.app.map import map_cli, map_main
from climap.app.predict import predict_cli, predict_main
from climap.app.train import train_cli, train_main

from climap import logger
from climap.utils.io import ClimapError
import tomli

def climap_cli():
    parser = argparse.ArgumentParser(prog="climap")
    sub = parser.add_subparsers(help="Subcommands", dest="cmd")
    map_cli(sub)
    predict_cli(sub)
    train_cli(sub)

    return parser.parse_args()

def dispatch(args):
    if args.cmd == "train":
        train_main(args)
    elif args.cmd == "predict":
        predict_main(args)
    elif args.cmd == "map":
        map_main(args)

def main():
    args = climap_cli()
    try:
        dispatch(args)
    except ClimapError as e:
        logger.exception(e)
    except tomli.TOMLDecodeError as e:
        logger.error(f"{args.input} is not valid.")
        logger.exception(e)
    except Exception as e:
        logger.exception(e)

if __name__ == "__main__":
    main()
