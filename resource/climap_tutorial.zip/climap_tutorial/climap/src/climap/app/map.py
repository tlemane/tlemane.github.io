import argparse
import json
from climap.utils.io import load_params, make_df
from climap.map import make_geodf, make_map

def map_main(args):
    params = load_params(args.model)
    params.input.path = f"{args.model}/predictions.tsv"
    df = make_df(params, no_index=True)
    gdf = make_geodf(df, latitude="Latitude", longitude="Longitude")

    if args.cls and args.cls != "" and params.config.mode == "regression":
        raise ClimapError("'--class' only available for classifiers.")

    if args.fig_params:
        args.fig_params = json.loads(args.fig_params)

    if args.cls:
        fig = make_map(gdf, args.cls, **args.fig_params)
    else:
        fig = make_map(gdf, f"{params.input.predict}_predicted", **args.fig_params)

    fig.savefig(f"{args.model}/map.{args.fig_format}", format=args.fig_format)

def map_cli(parser: argparse.ArgumentParser):
    mp = parser.add_parser("map", help="Plot predictions on map")
    mp.add_argument("--model", help="Model directory", required=True, metavar="DIR")
    mp.add_argument("--fig-format", help="Output format (any format supported by matplotlib)", default="svg", metavar="STR")
    mp.add_argument("--fig-params", help="Additional plotting parameters (ex: --params '{\"markersize\":0.5}')", default="{}", metavar="DICT")
    mp.add_argument("--cls", help="The class to plot, only for classifiers and probability predictions (ex: in 0/1 classification, --cls 1 or --cls 0), ", metavar="STR")


