import argparse
import os
from climap.utils.io import make_df, load_params, check_df, load_model, ClimapError
from climap import logger

def predict_main(args):
    params = load_params(args.model)
    model = load_model(args.model)
    params.input.path = args.features
    params.df = make_df(params, no_index=True)
    check_df(params.df, params.input.features)

    if params.config.mode == "regression" or args.type == "value":
        logger.info("Make predictions, with features = {f}", f=params.input.features)
        predictions = model.predict(params.df, params.input.features)
    elif args.type == "proba":
        logger.info("Make probability predictions, with features = {f}", f=params.input.features)
        predictions = model.predict_proba(params.df, params.input.features)

    out = f"{os.path.abspath(args.model)}/predictions.tsv"
    predictions.to_csv(out, sep="\t")
    logger.info("Predictions saved at '{p}'", p=out)


def predict_cli(parser: argparse.ArgumentParser):
    mp = parser.add_parser("predict", help="Make predictions")

    mp.add_argument("--features", help="Path to feature observations (tsv)", required=True, metavar="PATH")
    mp.add_argument("--model", help="Model directory", required=True, metavar="DIR")
    mp.add_argument("--type", help="Predict probabilities (only for classifiers) or values", choices=["value", "proba"], default="value")


