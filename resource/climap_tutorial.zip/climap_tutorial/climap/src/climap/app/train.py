import os
import argparse
import pickle
from climap.utils.io import parse_toml, check_toml_input, make_df, save_model, save_params
from climap.utils.eval import try_eval

from climap.model.classifiers import CLASSIFIERS
from climap.model.regressors import REGRESSORS

from climap.model import EnsembleVoting, EnsembleStacking

from sklearn.model_selection import ShuffleSplit, StratifiedKFold, KFold

from climap import logger

def check_df(df, features, to_predict):
    for f in features:
        if f not in df:
            raise RuntimeError(f"'{f}' feature does not exist.")
    if to_predict not in df:
        raise RuntimeError(f"'{to_predict}' does not exist.")

def make_cv(params):
    if params.cv.method == "kfold":
        cv = KFold(**params.cv.params["kfold"])
    elif params.cv.method == "skfold":
        cv = StratifiedKFold(**params.cv.params["skfold"])
    else:
        cv = ShuffleSplit(**params.cv.params["shuffle"])
    return cv

def make_and_train_model(name, params, mparams):
    logger.info("Make: {name}, with params = {p}", name=name, p = mparams.params)

    if params.config.mode == "regression":
        method = REGRESSORS[name]
    else:
        method = CLASSIFIERS[name]

    m = method(params.df, params.input.features, params.input.predict, **mparams.params)

    if params.ensemble:
        return m, mparams.grid

    if mparams.grid:
        logger.info("Tuning with: {grid}", grid=grid)
        logger.info("CV strategy: {name}, with scoring = '{score}', and params = {params}",
                    name=params.cv.method,
                    score=params.cv.scoring,
                    params=params.cv.params[params.cv.method])

        cv = make_cv(params)
        m.grid_tuning(grid = mparams.grid, cv = cv, scoring = params.cv.scoring, **params.cv.extra)
        return m, mparams.grid
    else:
        return m.fit(), mparams.grid

def make_ep(df, models, params):
    if params.ensemble.mode == "voting":
        return EnsembleVoting(df, params.input.features, params.input.predict, estimators=[(k, v[0]) for k, v in models.items()], **params.ensemble.params)
    elif params.ensemble.mode == "stacking":
        if params.config.mode == "regression":
            method = REGRESSORS[params.ensemble.method]
        else:
            method = CLASSIFIERS[params.ensemble.method]

        f = method(params.df, params.input.features, params.input.predict, **params.ensemble.fparams)

        return EnsembleStacking(df, params.input.features, params.input.predict, estimators=[(k, v[0]) for k, v in models.items()], final=f, **params.ensemble.params)

def make_and_train_ep(df, models, params):
    ep = make_ep(df, models, params)

    if params.ensemble.mode == "stacking":
        logger.info("Train: {name}({nm}), with params = {params} and fparams = {fparams}", name="EnsembleStacking",
                                                nm=params.ensemble.method,
                                                params=params.ensemble.params,
                                                fparams=params.ensemble.fparams)
    else:
        logger.info("Train: {name}, with params = {params}", name="EnsembleVoting",
                                                params=params.ensemble.params)

    grid = {}
    for k, m in models.items():
        for k1, v1 in m[1].items():
            grid[f"{k}__{k1}"] = v1

    for k, v in params.ensemble.grid.items():
        grid[f"final_estimator__{k}"] = v

    logger.info("Tuning with: {grid}", grid=grid)
    logger.info("CV strategy: {name}, with scoring = '{score}', and params = {params}", name=params.cv.method, score=params.cv.scoring, params=params.cv.params[params.cv.method])

    if grid != {}:
        ep.grid_tuning(grid = grid, scoring = params.cv.scoring, cv = make_cv(params), **params.cv.extra)
    else:
        ep.fit()

    return ep

def make_and_train_models(df, params):
    logger.info("Models: {ms}", ms=[k for k, v in params.methods.items()])
    models = {k: make_and_train_model(k, params, v) for k, v in params.methods.items()}
    return models

def train_main(args):
    logger.info("Input parsing and validation")
    params = parse_toml(args.input)
    params = check_toml_input(params)
    logger.info("Data: {data}, Mode: {mode}", data=params.input.path, mode=params.config.mode)
    df = make_df(params)
    params.df = df

    check_df(df, params.input.features, params.input.predict)

    models = make_and_train_models(df, params)

    os.makedirs(args.output, exist_ok=True)

    if params.ensemble:
        ep = make_and_train_ep(df, models, params)
        save_model("model", ep, args.output)
    else:
        save_model("model", models[0], args.output)

    save_params(args.input, params, args.output)

def train_cli(parser: argparse.ArgumentParser):
    mp = parser.add_parser("train", help="Model training")

    mp.add_argument("--input", help="Path to toml input file", required=True, metavar="PATH")
    mp.add_argument("--output", help="Output directory", required=True, metavar="DIR")


