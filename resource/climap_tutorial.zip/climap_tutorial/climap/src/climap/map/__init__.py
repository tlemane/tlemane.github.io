import pandas as pd
import geopandas as gpd
import contextily as cx
import xyzservices.providers as xyz

from folium import Map
from shapely.geometry import Point

def make_geodf(df: pd.DataFrame, latitude: str, longitude: str, crs="EPSG:4326"):
    geom = [Point(xy) for xy in zip(df[longitude], df[latitude])]
    gdf = gpd.GeoDataFrame(df, geometry=geom, crs=crs)
    return gdf

def make_map(gdf: gpd.GeoDataFrame, col: str, ax = None, source = cx.providers.CartoDB.PositronNoLabels, **kwargs):
    if ax:
        p = gdf.plot(col, ax=ax, **kwargs)
    else:
        p = gdf.plot(col, **kwargs)

    cx.add_basemap(p, crs=gdf.crs, source=source)

    return p.get_figure()

def make_interactive_map(gdf: gpd.GeoDataFrame, col: str, tiles=xyz.CartoDB.PositronNoLabels,
                         folium_kwds = {}, gpd_kwds = {}):
    m = Map(tiles=tiles.url, attr=tiles.attribution, **folium_kwds)
    return gdf.explore(col, m=m, **gpd_kwds)

