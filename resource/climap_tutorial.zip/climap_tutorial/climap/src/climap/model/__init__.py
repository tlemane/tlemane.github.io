import pandas as pd

from sklearn.exceptions import ConvergenceWarning
import warnings
warnings.filterwarnings("ignore", category=ConvergenceWarning)

import pickle
from sklearn.base import BaseEstimator, is_classifier
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn.inspection import permutation_importance
from sklearn.ensemble import VotingClassifier, StackingClassifier
from sklearn.ensemble import VotingRegressor, StackingRegressor

import numpy as np
from typing import Type, List, Any, Dict, Tuple, Callable, Iterable, Union

class Model:
    def __init__(self,
                 method: Type[BaseEstimator],
                 df: pd.DataFrame,
                 x: List[str],
                 y: str, **params):
        self.features = x
        self.p = y
        self.X = df[self.features]
        self.Y = np.ravel(df[[y]])
        self.tune = None
        self.estimator = method(**params)

    def grid_tuning(self,
                    grid: Dict[str, Any],
                    scoring: Union[str, Callable, List[str], Tuple[str], None] = None,
                    cv: Union["cv_splitter", int, Iterable] = None,
                    **params) -> GridSearchCV:
        self.tune = GridSearchCV(self.estimator, param_grid=grid, scoring=scoring, cv=cv, **params)
        self.tune.fit(self.X, self.Y)
        self.best_model()
        return self

    def randomized_tuning(self,
                          dist,
                          scoring: Union[str, Callable, List[str], Tuple[str], None] = None,
                          cv: Union["cv_splitter", int, Iterable] = None,
                          **params) -> RandomizedSearchCV:
        self.tune = RandomizedSearchCV(self.estimator, dist, scoring=scoring, cv=cv, **params)
        self.tune.fit(self.X, self.Y)
        self.best_model()

    def fit(self):
        self.estimator.fit(self.X, self.Y)
        return self

    def best_model(self):
        if self.tune:
            self.estimator.set_params(**self.tune.best_params_)
            self.estimator.fit(self.X, self.Y)
        else:
            self.fit()
        return self

    def feature_importance(self, mode=None, **params):
        if mode == "permutation":
            res = permutation_importance(self.estimator, self.X, self.Y, **params)
            return pd.Series(res.importances_mean, index=self.features)
        elif mode is None or mode == "impurity":
            return pd.Series(self.estimator.feature_importances_, index=self.features)
        else:
            raise RuntimeError("")

    def predict(self, df: pd.DataFrame, features: List[str], suffix="predicted") -> pd.DataFrame:
        preds = self.estimator.predict(df[features])
        res = df.copy()
        res[f"{self.p}_{suffix}"] = preds
        return res

    def predict_proba(self, df: pd.DataFrame, features: List[str], suffix="probability") -> pd.DataFrame:
        if not is_classifier(self.estimator):
            raise RuntimeError("'predict_proba' only available for classifiers.")
        preds = self.estimator.predict_proba(df[features])
        res = pd.DataFrame(preds, columns=self.estimator.classes_)
        return pd.concat([df, res], axis=1)

    @property
    def score(self) -> float:
        return self.tune.best_score_

    @property
    def model(self):
        return self.estimator

    @property
    def params_cv(self):
        return self.tune.best_params_

    @property
    def params(self):
        return self.estimator.get_params()

    @property
    def report(self):
        df = pd.DataFrame(self.tune.cv_results_)
        df.index = [f"Model_{x}" for x in range(len(df))]
        return df.drop(columns=["params"])

    def __getstate__(self):
        return { "p": self.p, "tune": self.tune, "estimator": self.estimator }

    def is_classifier(self):
        return is_classifier(self.estimator)

class EnsembleBase:
    def __init__(self, df, x, y, estimators) -> None:
        self.features = x
        self.estimators = estimators
        self.p = y
        self.X = df[self.features]
        self.Y = np.ravel(df[[self.p]])
        self.tune = None
        self.m = None
        self.meta = None

    def predict(self, df: pd.DataFrame, features: List[str], suffix="predicted") -> pd.DataFrame:
        preds = self.meta.predict(df[features])
        res = df.copy()
        res[f"{self.estimators[0][1].p}_{suffix}"] = preds
        return res

    def predict_proba(self, df: pd.DataFrame, features: List[str], suffix="probability") -> pd.DataFrame:
        if not is_classifier(self.meta):
            raise RuntimeError("'predict_proba' only available for classifiers.")

        preds = self.meta.predict_proba(df[features])
        res = pd.DataFrame(preds, columns=self.meta.classes_)
        return pd.concat([df, res], axis=1)

    def grid_tuning(self,
                    grid: Dict[str, Any],
                    scoring: Union[str, Callable, List[str], Tuple[str], None] = None,
                    cv: Union["cv_splitter", int, Iterable] = None,
                    **params) -> GridSearchCV:
        self.tune = GridSearchCV(self.meta, param_grid=grid, scoring=scoring, cv=cv, **params)
        self.meta = self.tune.fit(self.X, self.Y)
        return self

    def fit(self):
        self.meta.fit(self.X, self.Y)
        return self

    @property
    def score(self) -> float:
        return self.tune.best_score_

    @property
    def model(self):
        return self.meta

    @property
    def params_cv(self):
        return self.tune.best_params_

    @property
    def params(self):
        return self.meta.get_params()

    @property
    def report(self):
        df = pd.DataFrame(self.tune.cv_results_)
        df.index = [f"Model_{x}" for x in range(len(df))]
        return df.drop(columns=["params"])


class EnsembleVoting(EnsembleBase):
    def __init__(self, df, x, y, estimators, **kwargs) -> None:
        super().__init__(df, x, y, estimators)
        self.m = VotingClassifier if self.estimators[0][1].is_classifier() else VotingRegressor
        self.meta = self.m(estimators=[(n, e.estimator) for n, e in estimators], **kwargs)
        self.voting = kwargs["voting"] if "voting" in kwargs else "hard"

class EnsembleStacking(EnsembleBase):
    def __init__(self, df, x, y, estimators, final, **kwargs) -> None:
        super().__init__(df, x, y, estimators)
        self.m = StackingClassifier if self.estimators[0][1].is_classifier() else StackingRegressor
        self.meta = self.m(estimators=[(n, e.estimator) for n, e in estimators], final_estimator=final.estimator if final else None, **kwargs)


#class EnsembleVoting:
#    def __init__(self, df, x, y, estimators, **kwargs) -> None:
#        self.features = x
#        self.estimators = estimators
#        self.m = VotingClassifier if self.estimators[0][1].is_classifier() else VotingRegressor
#        self.meta = self.m(estimators=[(n, e.estimator) for n, e in estimators], **kwargs)
#        self.p = y
#        self.X = df[self.features]
#        self.Y = np.ravel(df[[y]])
#        self.tune = None
#        if "voting":
#            self.voting = kwargs["voting"]
#        else:
#            self.voting = "hard"
#
#    def predict(self, df: pd.DataFrame, features: List[str], suffix="predicted") -> pd.DataFrame:
#        preds = self.meta.predict(df[features])
#        res = df.copy()
#        res[f"{self.estimators[0][1].p}_{suffix}"] = preds
#        return res
#
#    def predict_proba(self, df: pd.DataFrame, features: List[str], suffix="probability") -> pd.DataFrame:
#        if not is_classifier(self.meta):
#            raise RuntimeError("'predict_proba' only available for classifiers.")
#
#        if self.voting == "hard":
#            raise RuntimeError("'predict_proba' only available for voting='soft'")
#
#        preds = self.meta.predict_proba(df[features])
#        res = pd.DataFrame(preds, columns=self.meta.classes_)
#        return pd.concat([df, res], axis=1)
#
#    def grid_tuning(self,
#                    grid: Dict[str, Any],
#                    scoring: Union[str, Callable, List[str], Tuple[str], None] = None,
#                    cv: Union["cv_splitter", int, Iterable] = None,
#                    **params) -> GridSearchCV:
#        self.tune = GridSearchCV(self.meta, param_grid=grid, scoring=scoring, cv=cv, **params)
#        self.meta = self.tune.fit(self.X, self.Y)
#        return self
#
#    def fit(self):
#        self.meta.fit(self.X, self.Y)
#        return self
#
#    @property
#    def score(self) -> float:
#        return self.tune.best_score_
#
#    @property
#    def model(self):
#        return self.meta
#
#    @property
#    def params_cv(self):
#        return self.tune.best_params_
#
#    @property
#    def params(self):
#        return self.meta.get_params()
#
#    @property
#    def report(self):
#        df = pd.DataFrame(self.tune.cv_results_)
#        df.index = [f"Model_{x}" for x in range(len(df))]
#        return df.drop(columns=["params"])
#
#
#class EnsembleStacking:
#    def __init__(self, df, x, y, estimators, final, **kwargs) -> None:
#        self.features = x
#        self.estimators = estimators
#        self.m = StackingClassifier if self.estimators[0][1].is_classifier() else StackingRegressor
#        self.meta = self.m(estimators=[(n, e.estimator) for n, e in estimators], final_estimator=final.estimator if final else None, **kwargs)
#        self.p = y
#        self.X = df[self.features]
#        self.Y = np.ravel(df[[y]])
#        self.tune = None
#
#    def grid_tuning(self,
#                    grid: Dict[str, Any],
#                    scoring: Union[str, Callable, List[str], Tuple[str], None] = None,
#                    cv: Union["cv_splitter", int, Iterable] = None,
#                    **params) -> GridSearchCV:
#        self.tune = GridSearchCV(self.meta, param_grid=grid, scoring=scoring, cv=cv, **params)
#        self.meta = self.tune.fit(self.X, self.Y)
#        return self
#
#    @property
#    def score(self) -> float:
#        return self.tune.best_score_
#
#    @property
#    def model(self):
#        return self.meta
#
#    @property
#    def params_cv(self):
#        return self.tune.best_params_
#
#    @property
#    def report(self):
#        df = pd.DataFrame(self.tune.cv_results_)
#        df.index = [f"Model_{x}" for x in range(len(df))]
#        return df.drop(columns=["params"])
#
#    @property
#    def params(self):
#        return self.meta.get_params()
#
#    def predict(self, df: pd.DataFrame, features: List[str], suffix="predicted") -> pd.DataFrame:
#        preds = self.meta.predict(df[features])
#        res = df.copy()
#        res[f"{self.estimators[0][1].p}_{suffix}"] = preds
#        return res
#
#    def predict_proba(self, df: pd.DataFrame, features: List[str], suffix="predicted") -> pd.DataFrame:
#        if not is_classifier(self.meta):
#            raise RuntimeError("'predict_proba' only available for classifiers.")
#
#        if self.voting == "hard":
#            raise RuntimeError("'predict_proba' only available for voting='soft'")
#
#        preds = self.meta.predict_proba(df[features])
#        res = pd.DataFrame(preds, columns=self.meta.classes_)
#        return pd.concat([df, res], axis=1)
#
#    def fit(self):
#        self.meta.fit(self.X, self.Y)
#        return self
#
#
