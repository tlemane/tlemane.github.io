import pandas as pd
from typing import List

from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.neural_network import MLPClassifier
from . import Model

class RandomForest(Model):
    def __init__(self, df: pd.DataFrame, x: List[str], y: str, **params) -> None:
        super().__init__(RandomForestClassifier, df, x, y, **params)

class GradientBoosting(Model):
    def __init__(self, df: pd.DataFrame, x: List[str], y: str, **params) -> None:
        super().__init__(GradientBoostingClassifier, df, x, y, **params)

class NeuralNet(Model):
    def __init__(self, df: pd.DataFrame, x: List[str], y: str, **params) -> None:
        super().__init__(MLPClassifier, df, x, y, **params)

class XGradientBoosting(Model):
    def __init__(self, df: pd.DataFrame, x: List[str], y: str, **params) -> None:
        super().__init__(XGBClassifier, df, x, y, **params)

CLASSIFIERS = {
    "RandomForest": RandomForest,
    "GradientBoosting": GradientBoosting,
    "NeuralNet": NeuralNet
}
