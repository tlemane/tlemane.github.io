import pandas as pd
from typing import List

from xgboost import XGBRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from . import Model

class RandomForest(Model):
    def __init__(self, df: pd.DataFrame, x: List[str], y: str, **params) -> None:
        super().__init__(RandomForestRegressor, df, x, y, **params)

class GradientBoosting(Model):
    def __init__(self, df: pd.DataFrame, x: List[str], y: str, **params) -> None:
        super().__init__(GradientBoostingRegressor, df, x, y, **params)

class NeuralNet(Model):
    def __init__(self, df: pd.DataFrame, x: List[str], y: str, **params) -> None:
        super().__init__(MLPRegressor, df, x, y, **params)

class XGradientBoosting(Model):
    def __init__(self, df: pd.DataFrame, x: List[str], y: str, **params) -> None:
        super().__init__(XGBRegressor, df, x, y, **params)

REGRESSORS = {
        "RandomForest": RandomForest,
        "GradientBoosting": GradientBoosting,
        "NeuralNet": NeuralNet
}
