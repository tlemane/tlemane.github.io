def try_eval(value):

    if isinstance(value, str) and value.startswith("pyeval:"):
        return eval(value[7:])

    if isinstance(value, dict):
        keys = value.keys()
        for k in keys:
            value[k] = try_eval(value[k])

    return value
