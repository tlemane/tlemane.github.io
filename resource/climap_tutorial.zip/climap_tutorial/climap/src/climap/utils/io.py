import os
import tomli
import shutil
import itertools
from pathlib import Path

import pandas as pd

from climap.utils.eval import try_eval
from climap.model.regressors import REGRESSORS
from climap.model.classifiers import CLASSIFIERS
from climap.utils.namespace import RecursiveNamespace
from climap import logger

from typing import Any
import pickle

class ClimapError(Exception):
    pass

def parse_toml(path: str) -> dict:
    with open(path, mode="rb") as f:
        return tomli.load(f)

def check_df(df, features, to_predict = None):
    for f in features:
        if f not in df:
            raise ClimapError(f"'{f}' feature does not exist.")
    if to_predict and to_predict not in df:
        raise ClimapError(f"'{to_predict}' does not exist.")

def check_section(name: str, namespace: RecursiveNamespace) -> None:
    if name not in namespace:
        raise ClimapError(f"'[{name}]' section is missing.")

def check_sections(*sections):
    for name, namespace in sections:
        check_section(name, namespace)

def check_field(name: str, section: str, namespace: RecursiveNamespace, default: Any) -> None:
    if name not in namespace:
        if default is not None:
            namespace[name] = default
        else:
            raise ClimapError(f"'{name}' is missing in section '[{section}]'")

def check_fields(*fields) -> None:
    for name, section, namespace, default in fields:
        check_field(name, section, namespace, default)

CLIMAP_CONFIG = "cv"
CLIMAP_CONFIG_MODE = "mode"

def check_config_section(data: RecursiveNamespace):
    check_section(CLIMAP_CONFIG, data)
    check_fields((CLIMAP_CONFIG_MODE, CLIMAP_CONFIG, data.config, None))

CLIMAP_INPUT = "input"
CLIMAP_INPUT_PATH = "path"
CLIMAP_INPUT_DEL = "delimiter"
CLIMAP_INPUT_INDEX = "index"
CLIMAP_INPUT_PREDICT = "predict"
CLIMAP_INPUT_FEATURES = "features"
CLIMAP_INPUT_READ_PARAMS = "params"
CLIMAP_INPUT_DEL_DEF = "\t"

def check_input_section(data: RecursiveNamespace) -> None:
    check_section(CLIMAP_INPUT, data)
    check_fields(
        (CLIMAP_INPUT_PATH, CLIMAP_INPUT, data.input, None),
        (CLIMAP_INPUT_FEATURES, CLIMAP_INPUT, data.input, None),
        (CLIMAP_INPUT_DEL, CLIMAP_INPUT, data.input, CLIMAP_INPUT_DEL_DEF),
        (CLIMAP_INPUT_READ_PARAMS, CLIMAP_INPUT, data.input, {})
    )

    path = Path(data.input.path)
    if not path.exists():
        raise FileNotFoundError(f"input.path = '{data.input.path}' does not exist.")

CLIMAP_CV = "cv"
CLIMAP_CV_METHOD = "method"
CLIMAP_CV_PARAMS = "params"
CLIMAP_CV_VALID_METHODS = ["kfold", "shuffle", "skfold"]
CLIMAP_CV_METHOD_DEF = "kfold"
CLIMAP_CV_PARAMS_DEF = {
    "kfold": { "n_splits": 5},
    "shuffle": { "n_splits": 5, "test_size": 0.30 },
    "skfold": { "n_splits": 5}
}
CLIMAP_CV_EXTRA = "extra"
CLIMAP_CV_SCORING = "scoring"
CLIMAP_CV_VALID_SCORING = {
    "classification": [
        "accuracy", "balanced_accuracy", "top_k_accuracy", "average_precision", "neg_brier_score",
        "f1", "f1_micro", "f1_macro", "f1.weighted", "f1_samples", "neg_log_loss", "precision",
        "recall", "jaccard", "roc_auc", "roc_auc_ovr", "roc_auc_ovo", "roc_auc_ovr_weighted",
        "roc_auc_ovo_weighted"
    ],
    "regression": [
        "explained_variance", "max_error", "neg_mean_absolute_error", "neg_mean_squared_error",
        "neg_root_mean_squared_error", "neg_mean_squared_log_error", "neg_median_absolute_error",
        "r2", "neg_mean_poisson_deviance", "neg_mean_gamma_deviance",
        "neg_mean_absolute_percentage_error", "d2_absolute_error_score", "d2_pinball_score",
        "d2_tweedie_score"
    ]
}
CLIMAP_CV_SCORING_DEF = {
    "classification": "accuracy",
    "regression": "neg_mean_squared_error"
}
def check_cv_section(data: RecursiveNamespace) -> None:
    check_section(CLIMAP_CV, data)

    check_fields(
        (CLIMAP_CV_METHOD, CLIMAP_CV, data.cv, CLIMAP_CV_METHOD_DEF),
        (CLIMAP_CV_PARAMS, CLIMAP_CV, data.cv, CLIMAP_CV_PARAMS_DEF),
    )

    if type(data.cv.params) != dict:
        data.cv.params = { data.cv.method : vars(data.cv.params) }

    if CLIMAP_CV_SCORING not in data.cv:
        data.cv.scoring = CLIMAP_CV_SCORING_DEF[data.config.mode]
    else:
        if data.cv.scoring not in CLIMAP_CV_VALID_SCORING[data.config.mode]:
            raise ClimapError(f"'[cv.scoring] = {data.cv.scoring}' is not supported.")

    if data.cv.method not in CLIMAP_CV_VALID_METHODS:
        raise ClimapError(f"'[cv.method] = {data.cv.method}' is not supported.")

    if CLIMAP_CV_EXTRA not in data.cv:
        data.cv.extra = {}
    else:
        e = vars(data.cv.extra)
        data.cv.extra = try_eval(e)

CLIMAP_METHODS = "methods"
CLIMAP_ENSEMBLE = "ensemble"
CLIMAP_ENSEMBLE_TYPE = "mode"
CLIMAP_METHODS_PARAMS = "params"
CLIMAP_METHODS_GRID = "grid"

def check_methods_section(data: RecursiveNamespace) -> None:
    check_section(CLIMAP_METHODS, data)

    x = len(data.methods)

    for n, v in data.methods.items():
        if n not in (x for x in itertools.chain(CLASSIFIERS, REGRESSORS)):
            raise ClimapError(f"{n} is not supported.")

        if CLIMAP_METHODS_GRID not in v:
            v.grid = {}
        else:
            g = vars(v.grid)
            v.grid = try_eval(g)

        if CLIMAP_METHODS_PARAMS not in v:
            v.params = {}
        else:
            p = vars(v.params)
            v.params = try_eval(p)

    if x > 1:
        check_section(CLIMAP_ENSEMBLE, data)

        if CLIMAP_ENSEMBLE_TYPE not in data.ensemble:
            data.ensemble.method = "voting"
        else:
            if data.ensemble.mode not in ("voting", "stacking"):
                raise ClimapError(f"'[ensemble.mode] = {data.ensemble.mode}' is not supported.")

        if CLIMAP_METHODS_PARAMS not in data.ensemble:
            data.ensemble.params = {}
        else:
            p = vars(data.ensemble.params)
            data.ensemble.params = try_eval(p)

        if CLIMAP_METHODS_GRID not in data.ensemble:
            data.ensemble.grid = {}
        else:
            g = vars(data.ensemble.grid)
            data.ensemble.grid = try_eval(g)

        if "fparams" not in data.ensemble:
            data.ensemble.fparams = {}
        else:
            f = vars(data.ensemble.fparams)
            data.ensemble.fparams = try_eval(f)
    else:
        data.ensemble = None


def check_toml_input(data: dict) -> RecursiveNamespace:
    data = RecursiveNamespace(**data)
    check_config_section(data)
    check_input_section(data)
    check_cv_section(data)
    check_methods_section(data)
    return data

def make_df(data: RecursiveNamespace, no_index = False) -> pd.DataFrame:
    path = Path(data[CLIMAP_INPUT][CLIMAP_INPUT_PATH])

    if no_index:
        df = pd.read_csv(data[CLIMAP_INPUT][CLIMAP_INPUT_PATH],
                     sep=data[CLIMAP_INPUT][CLIMAP_INPUT_DEL],
                     **data[CLIMAP_INPUT][CLIMAP_INPUT_READ_PARAMS])
    else:
        df = pd.read_csv(data[CLIMAP_INPUT][CLIMAP_INPUT_PATH],
                     sep=data[CLIMAP_INPUT][CLIMAP_INPUT_DEL],
                     index_col=data[CLIMAP_INPUT][CLIMAP_INPUT_INDEX],
                     **data[CLIMAP_INPUT][CLIMAP_INPUT_READ_PARAMS])
    return df


def save_model(name: str, model, output: str, cv = True) -> None:
    apath = os.path.abspath(output)
    mpath = f"{apath}/model.bin"
    spath = f"{apath}/report.tsv"

    with open(mpath, mode="wb") as pout:
        pickle.dump(model, pout)

    logger.info("Model saved at '{path}'", path = f"{apath}/model.bin")

    model.report.to_csv(spath, sep="\t")
    logger.info("Report saved at '{path}'", path = f"{apath}/report.tsv")

def save_params(toml: str, params: RecursiveNamespace, output: str) -> None:
    tpath = f"{output}/params.toml"
    npath = f"{output}/params.bin"

    with open(npath, mode="wb") as nout:
        pickle.dump(params, nout)

    shutil.copyfile(toml, tpath)

    logger.info("Params saved at '{path}'", path = f"{os.path.abspath(output)}/params.toml")

def load_model(model: str):
    with open(f"{model}/model.bin", mode="rb") as fin:
        return pickle.load(fin)

def load_params(model: str) -> RecursiveNamespace:
    with open(f"{model}/params.bin", mode="rb") as fin:
        return pickle.load(fin)
