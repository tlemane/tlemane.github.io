from types import SimpleNamespace

class RecursiveNamespace(SimpleNamespace):
    def __init__(self, **kwargs):
        self.__dict__.update({k: self.__rec(v) for k, v in kwargs.items()})

    def __rec(self, e):
        if type(e) == dict:
            return RecursiveNamespace(**e)
        elif type(e) in (list, tuple):
            return [self.__rec(i) for i in e]
        return e

    def __contains__(self, k):
        return k in self.__dict__

    def __getitem__(self, k):
        return self.__dict__[k]

    def __setitem__(self, k, value):
        self.__dict__[k] = value

    def __len__(self):
        return len(self.__dict__)

    def items(self):
        return self.__dict__.items()



class RecursiveNamespace2(SimpleNamespace):
    # def __init__(self, /, **kwargs):  # better, but Python 3.8+
    def __init__(self, **kwargs):
        """Create a SimpleNamespace recursively"""
        self.__dict__.update({k: self.__elt(v) for k, v in kwargs.items()})

    def __elt(self, elt):
        """Recurse into elt to create leaf namespace objects"""
        if type(elt) is dict:
            return type(self)(**elt)
        if type(elt) in (list, tuple):
            return [self.__elt(i) for i in elt]
        return elt

